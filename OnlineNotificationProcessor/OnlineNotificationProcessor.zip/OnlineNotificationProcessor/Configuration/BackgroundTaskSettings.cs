﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OnlineNotificationProcessor.Configuration
{
    public class BackgroundTaskSettings
    {
        public string ConnectionString { get; set; }

        public string EventBusConnection { get; set; }

        //Any other configruation/setting

    }
}
